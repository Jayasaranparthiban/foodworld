from django.apps import AppConfig


class FoodworldConfig(AppConfig):
    name = 'food_world'
